﻿create database QLBHL2 --CSDL Lab 2
go
use QLBHL2
go
Create table KhachHang
( 
	MaKhachHang nvarchar(5) not null,
	HovaTen nvarchar(200) not null,
	Diachi nvarchar(200) not null,
	DienThoai nvarchar (200) not null,
	constraint PK_KhachHang primary key(MaKhachHang)
)
go
create table TaiKhoan
(
	SoTK nvarchar(50) not null,
	MaKhachHang nvarchar(5) not null,
	NgayMoTK datetime not null,
	SoTien nvarchar(150) not null,
	constraint PK_TaiKhoan primary key(SoTK),
	constraint PK_TaiKhoan_KhachHang foreign key(MaKhachHang) references KhachHang(MaKhachHang)
)
go
create table GiaoDich
(
	MaGD nvarchar(50) not null,
	SoTK nvarchar(50) not null,
	ThoiGianGD datetime not null,
	SoTienGD nvarchar(150) not null,
	MoTa nvarchar(150) not null,
	SoDuTaiKhoan nvarchar(150) not null,
	constraint PK_GiaoDich primary key(MaGD),
	constraint PK_GiaoDich_TaiKhoan foreign key(SoTK) references TaiKhoan (SoTK)
)
go

INsert into KhachHang(MaKhachHang,HovaTen,Diachi,Email,DienThoai)
Values ('KH01',N'Nguyễn văn Kiều',N'Vĩnh Phúc','0987654321')
INsert into KhachHang(MaKhachHang,HovaTen,Diachi,Email,DienThoai)
Values ('KH02',N'Nguyễn văn Bậu',N'Vĩnh Phúc','0987256431')
INsert into KhachHang(MaKhachHang,HovaTen,Diachi,Email,DienThoai)
Values ('KH03',N'Nguyễn văn Bậu',N'Vĩnh Phúc','0987256431')
INsert into KhachHang(MaKhachHang,HovaTen,Diachi,Email,DienThoai)
Values ('KH04',N'Nguyễn văn Bậu',N'Vĩnh Phúc','0987256431')
INsert into KhachHang(MaKhachHang,HovaTen,Diachi,Email,DienThoai)
Values ('KH05',N'Nguyễn văn Bậu',N'Vĩnh Phúc','0987256431')

insert  into TaiKhoan(SoTK,MaKhachHang,NgayMoTK,SoTien)
Values ('0321','KH01',01-15-2021,10000000)


insert into GiaoDich(MaGD,SoTK,ThoiGianGD,SoTienGD,MoTa,SoDuTaiKhoan)
values ('k01','0321',1-15-2021,50000,N' đánh Lô',9500000)

select * from KhachHang
select * from TaiKhoan
select * from GiaoDich